import { ShieldCheck, User, LogOut, KeyRound } from 'lucide-react';
import { User as UserType } from '../utils/mockDatabase';

interface HeaderProps {
  user: UserType | null;
  onLogout: () => void;
  onNavigate: (view: string) => void;
  currentView: string;
}

export default function Header({ user, onLogout, onNavigate, currentView }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 flex h-16 w-full items-center justify-between border-b border-slate-200 bg-white/80 px-6 backdrop-blur-md shadow-sm">
      <div 
        className="flex cursor-pointer items-center space-x-3"
        onClick={() => onNavigate('dashboard')}
      >
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-600 text-white shadow-md shadow-indigo-100">
          <ShieldCheck className="h-6 w-6 font-bold" />
        </div>
        <span className="text-xl font-bold tracking-tight text-slate-800">
          Auth<span className="text-indigo-600">Verify</span>
        </span>
      </div>

      <div className="flex items-center space-x-4">
        {user ? (
          <div className="flex items-center space-x-3">
            <div className="flex flex-col text-right hidden sm:flex">
              <span className="text-sm font-medium text-slate-700">{user.fullName}</span>
              <span className="text-xs text-slate-400 font-normal">{user.email}</span>
            </div>
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-100 text-slate-600 border border-slate-200 cursor-pointer">
              <User className="h-5 w-5" />
            </div>
            <button
              onClick={onLogout}
              className="flex h-10 w-10 items-center justify-center rounded-lg hover:bg-red-50 text-slate-500 hover:text-red-600 transition-colors"
              title="Logout"
            >
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        ) : (
          <div className="flex items-center space-x-2">
            <button
              onClick={() => onNavigate('login')}
              className={`flex items-center space-x-1 px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
                currentView === 'login' 
                ? 'bg-slate-100 text-slate-800' 
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <KeyRound className="h-4 w-4" />
              <span>Login</span>
            </button>
            <button
              onClick={() => onNavigate('register')}
              className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition-colors"
            >
              Register
            </button>
          </div>
        )}
      </div>
    </header>
  );
}
