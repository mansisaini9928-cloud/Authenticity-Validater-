import { 
  LayoutDashboard, 
  FileSearch, 
  Video, 
  FileText, 
  ShieldCheck,
  History
} from 'lucide-react';

interface SidebarProps {
  currentView: string;
  onNavigate: (view: string) => void;
}

export default function Sidebar({ currentView, onNavigate }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Overview', icon: LayoutDashboard },
    { id: 'forgery', label: 'Document & Images', icon: FileSearch },
    { id: 'media', label: 'Audio & Video', icon: Video },
    { id: 'text', label: 'Threat & Scam Text', icon: FileText },
    { id: 'history', label: 'Verification Logs', icon: History },
  ];

  return (
    <aside className="w-64 border-r border-slate-200 bg-slate-50 h-[calc(100vh-4rem)] sticky top-16 p-4 hidden md:flex flex-col justify-between">
      <div className="space-y-1">
        <p className="px-3 text-xs font-semibold uppercase tracking-wider text-slate-400 mb-4">
          Navigation
        </p>
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`flex w-full items-center space-x-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-100 font-semibold'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Icon className={`h-5 w-5 ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-600'}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      <div className="bg-gradient-to-br from-indigo-50 to-violet-50 p-4 rounded-2xl border border-indigo-100">
        <div className="flex items-center space-x-2 text-indigo-700 font-semibold text-sm mb-1">
          <ShieldCheck className="h-4 w-4 text-indigo-500" />
          <span>Real-time Safety</span>
        </div>
        <p className="text-xs text-slate-500 leading-relaxed">
          Validation processes run securely over localized secure network hashing setups.
        </p>
      </div>
    </aside>
  );
}
