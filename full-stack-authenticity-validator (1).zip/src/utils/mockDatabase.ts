// Mock Database & Logic Engine for Authenticity Validator

export interface User {
  id: string;
  fullName: string;
  email: string;
  password?: string;
  created_at: string;
}

export interface ScanResult {
  id: string;
  userId?: string;
  fileName: string;
  fileType: 'document' | 'image' | 'audio' | 'video' | 'text';
  category: 'forgery' | 'media' | 'scam_text';
  authenticityScore: number; // 0 - 100
  status: 'safe' | 'suspicious' | 'danger';
  scannedAt: string;
  details: {
    title: string;
    description: string;
    threatsDetected: string[];
    metadata?: Record<string, string | number | boolean>;
  };
}

// Scam words list for text verification
const SCAM_KEYWORDS = [
  "lottery", "jackpot", "urgent cash", "bitcoin double", "send bank details",
  "verify your ssn", "wire money", "claim prize", "free crypto", "unauthorized transaction",
  "account suspended", "click link instantly", "gift card", "inherit money"
];

const THREAT_KEYWORDS = [
  "kill", "destroy", "hack your system", "ransomware", "leak information",
  "bomb", "extort", "compromised password", "download malware", "infect computer"
];

// Database operations
export const mockDB = {
  // Authentication
  getUsers: (): User[] => {
    const users = localStorage.getItem('auth_users');
    return users ? JSON.parse(users) : [];
  },

  registerUser: (fullName: string, email: string, password: string): { success: boolean; message: string; user?: User } => {
    const users = mockDB.getUsers();
    if (users.find(u => u.email === email)) {
      return { success: false, message: 'Email already registered' };
    }
    const newUser: User = { id: Math.random().toString(36).substr(2, 9), fullName, email, created_at: new Date().toISOString() };
    // In a real app we'd hash the password. Store plain/encoded for local testing
    localStorage.setItem('auth_users', JSON.stringify([...users, { ...newUser, password }]));
    return { success: true, message: 'Registration successful', user: newUser };
  },

  loginUser: (email: string, password: string): { success: boolean; message: string; user?: User } => {
    const users = mockDB.getUsers() as any[];
    const user = users.find(u => u.email === email && u.password === password);
    if (!user) {
      return { success: false, message: 'Invalid email or password' };
    }
    const { password: _, ...userNoPassword } = user;
    return { success: true, message: 'Login successful', user: userNoPassword };
  },

  // Scans Tracking
  getScans: (userId?: string): ScanResult[] => {
    const scans = localStorage.getItem('auth_scans');
    const allScans: ScanResult[] = scans ? JSON.parse(scans) : [];
    if (userId) {
      return allScans.filter(s => s.userId === userId);
    }
    return allScans;
  },

  addScan: (scanData: Omit<ScanResult, 'id' | 'scannedAt'>): ScanResult => {
    const scans = mockDB.getScans();
    const newScan: ScanResult = {
      ...scanData,
      id: 'scan_' + Math.random().toString(36).substr(2, 9),
      scannedAt: new Date().toISOString()
    };
    localStorage.setItem('auth_scans', JSON.stringify([newScan, ...scans]));
    return newScan;
  },

  // Verification Processing Logic
  analyzeText: (text: string, userId?: string): ScanResult => {
    const textLower = text.toLowerCase();
    const threats: string[] = [];
    let threatScore = 0;

    SCAM_KEYWORDS.forEach(word => {
      if (textLower.includes(word)) {
        threats.push(`Scam Keyword found: "${word}"`);
        threatScore += 20;
      }
    });

    THREAT_KEYWORDS.forEach(word => {
      if (textLower.includes(word)) {
        threats.push(`Threat/Extortion Keyword: "${word}"`);
        threatScore += 35;
      }
    });

    if (textLower.includes('http://') || textLower.includes('https://')) {
      threats.push('External Link Tracking (Potential phishing)');
      threatScore += 10;
    }

    const finalScore = Math.max(0, 100 - threatScore);
    const status = finalScore > 75 ? 'safe' : finalScore > 40 ? 'suspicious' : 'danger';

    return mockDB.addScan({
      userId,
      fileName: 'Text Analysis Snippet',
      fileType: 'text',
      category: 'scam_text',
      authenticityScore: finalScore,
      status,
      details: {
        title: status === 'safe' ? 'Safe Text Output' : 'Suspicious Elements Detected',
        description: `This text evaluated to a score of ${finalScore}/100 in our threat profile analysis.`,
        threatsDetected: threats.length ? threats : ['No known scams or threats detected in simple verification.']
      }
    });
  },

  analyzeDocument: (file: File, fileType: 'document' | 'image', userId?: string): ScanResult => {
    // Simulated metadata analysis
    const isPDF = file.name.endsWith('.pdf');
    const isImg = file.type.startsWith('image/');

    // Randomize score but tie some to filenames to make it interactive
    let score = Math.floor(Math.random() * 30) + 70; // 70-100 random
    if (file.name.toLowerCase().includes('fake') || file.name.toLowerCase().includes('edit')) {
      score = Math.floor(Math.random() * 20) + 15; // 15-35
    }

    const status = score > 80 ? 'safe' : score > 50 ? 'suspicious' : 'danger';
    const threats = [];

    if (score < 80) {
      if (isPDF) threats.push('Digital Signature discrepancy');
      if (isImg) threats.push('Pixel manipulation & cloning detected');
      threats.push('File metadata has been altered or stripped');
    }

    return mockDB.addScan({
      userId,
      fileName: file.name,
      fileType,
      category: 'forgery',
      authenticityScore: score,
      status,
      details: {
        title: 'File Consistency Report',
        description: `Authenticity checking finished for ${file.name}. Validated format integrity.`,
        threatsDetected: threats.length ? threats : ['Integrity validation passed. Normal usage patterns detected.'],
        metadata: {
          'File Name': file.name,
          'File Size': (file.size / 1024).toFixed(2) + ' KB',
          'MIME Type': file.type || 'application/octet-stream',
          'Altered Date': new Date().toLocaleDateString(),
          'Compression Check': 'Standard compliant'
        }
      }
    });
  },

  analyzeMedia: (file: File, type: 'audio' | 'video', userId?: string): ScanResult => {
    let score = Math.floor(Math.random() * 40) + 60; // 60-100
    if (file.name.toLowerCase().includes('deepfake') || file.name.toLowerCase().includes('clone')) {
      score = Math.floor(Math.random() * 30) + 10; 
    }

    const status = score > 80 ? 'safe' : score > 50 ? 'suspicious' : 'danger';
    const threats = [];

    if (status !== 'safe') {
      if (type === 'video') {
        threats.push('Frame discontinuity / AI face swap signatures');
      } else {
        threats.push('Voice waveform synthesis / Pitch modulation signatures');
      }
    }

    return mockDB.addScan({
      userId,
      fileName: file.name,
      fileType: type,
      category: 'media',
      authenticityScore: score,
      status,
      details: {
        title: 'Audio/Video Synthetics Scan',
        description: `Inspected audio frequencies and visual metadata artifacting on ${file.name}.`,
        threatsDetected: threats.length ? threats : ['No generative AI or synthesize components verified.'],
        metadata: {
          'File Name': file.name,
          'Stream Analysis': 'Complete',
          'Encoding Standard': 'Standard compliant',
          'Voiceprints Checked': type === 'audio' ? 'Yes' : 'N/A'
        }
      }
    });
  }
};
