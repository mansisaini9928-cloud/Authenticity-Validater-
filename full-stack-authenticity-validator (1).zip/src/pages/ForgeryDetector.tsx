import React, { useState } from 'react';
import { 
  FileSearch, Upload, CheckCircle2, AlertCircle, AlertOctagon,
  Loader2, ShieldAlert, Sparkles, RefreshCw
} from 'lucide-react';
import { mockDB, ScanResult } from '../utils/mockDatabase';

interface ForgeryDetectorProps {
  user: any;
}

export default function ForgeryDetector({ user }: ForgeryDetectorProps) {
  const [file, setFile] = useState<File | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<ScanResult | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setResult(null);
    }
  };

  const handleAnalyze = () => {
    if (!file) return;
    setAnalyzing(true);
    
    // Simulate back-end process timeout
    setTimeout(() => {
      const type = file.type.startsWith('image/') ? 'image' : 'document';
      const scanResult = mockDB.analyzeDocument(file, type, user?.id);
      setResult(scanResult);
      setAnalyzing(false);
    }, 2500);
  };

  const resetScanner = () => {
    setFile(null);
    setResult(null);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 tracking-tight flex items-center space-x-2">
            <FileSearch className="h-6 w-6 text-indigo-600 font-semibold" />
            <span>Document & Image Forgery Auditing</span>
          </h1>
          <p className="text-slate-500 text-xs mt-1">
            Detect vector overlays, manipulation artifacts, metadata tampering, and signature fraud.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Upload Container */}
        <div className="lg:col-span-3 space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
            <div className="border-2 border-dashed border-slate-200 hover:border-indigo-400 hover:bg-slate-50/50 rounded-xl p-8 text-center cursor-pointer transition-all relative">
              <input 
                type="file" 
                accept=".pdf,.png,.jpg,.jpeg,.doc,.docx"
                onChange={handleFileChange}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
              
              <div className="space-y-3">
                <div className="h-12 w-12 bg-indigo-50 text-indigo-600 rounded-xl mx-auto flex items-center justify-center">
                  <Upload className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-700">
                    {file ? file.name : "Click or drag to add files"}
                  </p>
                  <p className="text-xs text-slate-400 mt-1">
                    Accepts PDF, JPG, PNG, DOCX (Max 25MB)
                  </p>
                </div>
              </div>
            </div>

            {file && !analyzing && !result && (
              <div className="mt-4 flex justify-end">
                <button
                  onClick={handleAnalyze}
                  className="flex items-center space-x-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-bold transition shadow"
                >
                  <Sparkles className="h-4 w-4" />
                  <span>Execute AI Scan</span>
                </button>
              </div>
            )}

            {analyzing && (
              <div className="mt-6 flex flex-col items-center justify-center text-center space-y-3 py-6">
                <Loader2 className="h-8 w-8 text-indigo-600 animate-spin" />
                <p className="text-sm font-semibold text-slate-700">Examining digital footprint...</p>
                <p className="text-xs text-slate-400">Verifying compression & hashing vectors</p>
              </div>
            )}
          </div>

          {/* Guidelines */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 space-y-3">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wide">Scanner Verification Metrics:</h4>
            <ul className="text-xs text-slate-500 space-y-2 leading-relaxed">
              <li className="flex items-start space-x-2">
                <CheckCircle2 className="h-4 w-4 text-indigo-500 mt-0.5 shrink-0" />
                <span><strong>Metadata scrubbing:</strong> Evaluates deleted headers or modified fields.</span>
              </li>
              <li className="flex items-start space-x-2">
                <CheckCircle2 className="h-4 w-4 text-indigo-500 mt-0.5 shrink-0" />
                <span><strong>Cloning validation:</strong> Filters layered masks or compressed brush lines.</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Results Container */}
        <div className="lg:col-span-2">
          {result ? (
            <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-5 animate-fadeIn">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-800">Scan Evaluation Result</h3>
                <button 
                  onClick={resetScanner} 
                  className="text-xs font-semibold text-slate-400 hover:text-slate-600 flex items-center space-x-1"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  <span>Reset</span>
                </button>
              </div>

              {/* Score ring */}
              <div className="flex flex-col items-center py-4 border-b border-slate-100">
                <div className={`h-24 w-24 rounded-full flex flex-col items-center justify-center border-4 border-slate-100 relative ${
                  result.status === 'safe' 
                    ? 'text-emerald-600 border-t-emerald-500 border-r-emerald-500' 
                    : result.status === 'suspicious' 
                    ? 'text-amber-500 border-t-amber-400 border-r-amber-400' 
                    : 'text-red-600 border-t-red-500 border-r-red-500'
                }`}>
                  <span className="text-2xl font-bold">{result.authenticityScore}%</span>
                  <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">score</span>
                </div>
                <span className={`text-xs font-bold mt-3 px-3 py-1 rounded-full border ${
                  result.status === 'safe' 
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-100' 
                    : result.status === 'suspicious' 
                    ? 'bg-amber-50 text-amber-700 border-amber-100' 
                    : 'bg-red-50 text-red-700 border-red-100'
                }`}>
                  {result.status.toUpperCase()}
                </span>
              </div>

              {/* Flags */}
              <div className="space-y-3">
                <div className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center space-x-1">
                  <ShieldAlert className="h-4 w-4 text-indigo-500" />
                  <span>Alert Summaries</span>
                </div>
                {result.details.threatsDetected.map((thr, index) => (
                  <div key={index} className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-start space-x-2.5">
                    {result.status === 'safe' ? (
                      <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                    ) : result.status === 'suspicious' ? (
                      <AlertCircle className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
                    ) : (
                      <AlertOctagon className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
                    )}
                    <p className="text-xs text-slate-600 leading-normal">{thr}</p>
                  </div>
                ))}
              </div>

              {/* Metadata Details */}
              {result.details.metadata && (
                <div className="space-y-2 border-t border-slate-100 pt-4">
                  <h4 className="text-xs font-bold text-slate-700">Extracted Header Metadata:</h4>
                  <div className="grid grid-cols-2 gap-2 text-[11px] font-medium text-slate-500">
                    {Object.entries(result.details.metadata).map(([key, val]) => (
                      <div key={key} className="bg-slate-50 p-2 rounded border border-slate-100">
                        <span className="text-slate-400 block mb-0.5">{key}</span>
                        <span className="text-slate-700 truncate block">{String(val)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-slate-50 border border-slate-200 border-dashed rounded-2xl p-10 text-center flex flex-col items-center justify-center text-slate-400 h-full min-h-[300px]">
              <FileSearch className="h-10 w-10 text-slate-300 mb-3" />
              <p className="text-xs font-semibold">Results will load here upon system initialization.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
