import { useState } from 'react';
import { 
  FileText, ShieldCheck, CheckCircle2, AlertCircle, AlertOctagon,
  Loader2, Search, RefreshCw
} from 'lucide-react';
import { mockDB, ScanResult } from '../utils/mockDatabase';

interface TextDetectorProps {
  user: any;
}

export default function TextDetector({ user }: TextDetectorProps) {
  const [inputText, setInputText] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<ScanResult | null>(null);

  const handleAnalyze = () => {
    if (!inputText.trim()) return;
    setAnalyzing(true);

    setTimeout(() => {
      const scanResult = mockDB.analyzeText(inputText, user?.id);
      setResult(scanResult);
      setAnalyzing(false);
    }, 1500);
  };

  const resetScanner = () => {
    setInputText('');
    setResult(null);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-800 tracking-tight flex items-center space-x-2">
          <FileText className="h-6 w-6 text-indigo-600 font-semibold" />
          <span>Scam & Threat Text Evaluator</span>
        </h1>
        <p className="text-slate-500 text-xs mt-1">
          Paste emails, suspicious links, SMS, or ransom threads to diagnose potential traps.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Input box */}
        <div className="lg:col-span-3 space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
            <div className="relative">
              <textarea
                rows={6}
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Paste message contents here... e.g., 'Dear user, you won a lottery. Click to wire money to claim BTC jackpot...'"
                className="w-full p-4 text-sm bg-slate-50 border border-slate-200 focus:border-indigo-400 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-50/50 resize-none transition-all placeholder:text-slate-400"
              />
              <span className="absolute bottom-4 right-4 text-[10px] font-medium text-slate-400">
                {inputText.length} chars
              </span>
            </div>

            <div className="mt-4 flex justify-end">
              <button
                onClick={handleAnalyze}
                disabled={!inputText.trim() || analyzing}
                className={`flex items-center space-x-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl text-sm font-bold transition shadow`}
              >
                {analyzing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                <span>{analyzing ? "Reading Semantics..." : "Scan Message"}</span>
              </button>
            </div>
          </div>

          <div className="bg-indigo-50/40 border border-indigo-100 rounded-2xl p-4 flex items-start space-x-3">
            <ShieldCheck className="h-5 w-5 text-indigo-600 mt-0.5 shrink-0" />
            <div className="space-y-1">
              <p className="text-xs font-bold text-slate-800">Lexical Scoring Protocol</p>
              <p className="text-xs text-slate-500 leading-relaxed">
                Weights against dictionary definitions pertaining to urgency, ransom prompts, and illicit credentials retrieval tactics.
              </p>
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="lg:col-span-2">
          {result ? (
            <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-5 animate-fadeIn">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-800">Scam Content Matrix</h3>
                <button 
                  onClick={resetScanner} 
                  className="text-xs font-semibold text-slate-400 hover:text-slate-600 flex items-center space-x-1"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  <span>Restart</span>
                </button>
              </div>

              <div className="flex flex-col items-center py-4 border-b border-slate-100">
                <div className={`h-24 w-24 rounded-full flex flex-col items-center justify-center border-4 border-slate-100 relative ${
                  result.status === 'safe' 
                    ? 'text-emerald-600 border-t-emerald-500 border-r-emerald-500' 
                    : result.status === 'suspicious' 
                    ? 'text-amber-500 border-t-amber-400 border-r-amber-400' 
                    : 'text-red-600 border-t-red-500 border-r-red-500'
                }`}>
                  <span className="text-2xl font-bold">{result.authenticityScore}%</span>
                  <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">cleanliness</span>
                </div>
                <span className={`text-xs font-bold mt-3 px-3 py-1 rounded-full border ${
                  result.status === 'safe' 
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-100' 
                    : result.status === 'suspicious' 
                    ? 'bg-amber-50 text-amber-700 border-amber-100' 
                    : 'bg-red-50 text-red-700 border-red-100'
                }`}>
                  {result.status.toUpperCase()}
                </span>
              </div>

              <div className="space-y-2">
                <div className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">Signals Spotted</div>
                {result.details.threatsDetected.map((thr, index) => (
                  <div key={index} className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-start space-x-2.5">
                    {result.status === 'safe' ? (
                      <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                    ) : result.status === 'suspicious' ? (
                      <AlertCircle className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
                    ) : (
                      <AlertOctagon className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
                    )}
                    <p className="text-xs text-slate-600 font-medium">{thr}</p>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="bg-slate-50 border border-slate-200 border-dashed rounded-2xl p-10 text-center flex flex-col items-center justify-center text-slate-400 h-full min-h-[300px]">
              <FileText className="h-10 w-10 text-slate-300 mb-3" />
              <p className="text-xs font-semibold">Ready for textual integrity queries.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
