import { 
  ShieldCheck, AlertTriangle, FileSearch, Video, FileText, ArrowRight,
  TrendingUp, Activity, CheckCircle2, AlertOctagon
} from 'lucide-react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer 
} from 'recharts';
import { mockDB } from '../utils/mockDatabase';

interface LandingDashboardProps {
  onNavigate: (view: string) => void;
  user: any;
}

export default function LandingDashboard({ onNavigate, user }: LandingDashboardProps) {
  const scans = mockDB.getScans(user?.id);
  
  const safeCount = scans.filter(s => s.status === 'safe').length;
  const suspiciousCount = scans.filter(s => s.status === 'suspicious').length;
  const dangerCount = scans.filter(s => s.status === 'danger').length;

  // Chart data
  const chartData = scans.slice(0, 7).reverse().map((scan, index) => ({
    name: `Scan ${index + 1}`,
    authenticity: scan.authenticityScore,
  }));

  // Standard graph fallback
  const fallbackData = [
    { name: 'Scan 1', authenticity: 85 },
    { name: 'Scan 2', authenticity: 90 },
    { name: 'Scan 3', authenticity: 65 },
    { name: 'Scan 4', authenticity: 95 },
  ];

  const categories = [
    {
      id: 'forgery',
      title: 'Forgery Detection',
      description: 'Check manipulated PDF documents, agreements, forms, or cloned digital image edits.',
      icon: FileSearch,
      color: 'indigo',
    },
    {
      id: 'media',
      title: 'Deepfake & Media Audit',
      description: 'Review audio voice clips, video frames, or audio streams for synthetic or synthesized markers.',
      icon: Video,
      color: 'violet',
    },
    {
      id: 'text',
      title: 'Spam & Threat Detector',
      description: 'Clean emails or texts from blackmail, unauthorized web anchors, or sensitive phishing tactics.',
      icon: FileText,
      color: 'blue',
    },
  ];

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-8 shadow-xl border border-slate-800 relative overflow-hidden">
        <div className="absolute right-[-40px] top-[-40px] h-60 w-60 rounded-full bg-indigo-500/10 blur-3xl" />
        <div className="max-w-xl space-y-3">
          <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
            <ShieldCheck className="h-4 w-4 mr-1.5" /> Ready to Secure
          </span>
          <h1 className="text-3xl font-bold tracking-tight">
            Advanced Forgery & Integrity Engine
          </h1>
          <p className="text-slate-400 text-sm leading-relaxed">
            Instantly measure document compliance, synthesize digital artifacts, or detect phishing alerts via centralized analysis.
          </p>
          <div className="pt-3">
            {!user && (
              <button
                onClick={() => onNavigate('register')}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold rounded-xl transition shadow-md shadow-indigo-500/20"
              >
                Unlock Unlimited History Access
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Grid Quick Options */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {categories.map((cat) => {
          const Icon = cat.icon;
          return (
            <div
              key={cat.id}
              onClick={() => onNavigate(cat.id)}
              className="group cursor-pointer bg-white border border-slate-200 hover:border-indigo-300 rounded-2xl p-6 transition-all duration-200 hover:shadow-lg hover:-translate-y-0.5 flex flex-col justify-between"
            >
              <div>
                <div className={`h-12 w-12 rounded-xl bg-slate-50 flex items-center justify-center text-slate-700 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors`}>
                  <Icon className="h-6 w-6" />
                </div>
                <h3 className="mt-4 text-base font-bold text-slate-800 tracking-tight">
                  {cat.title}
                </h3>
                <p className="mt-2 text-xs text-slate-500 leading-relaxed">
                  {cat.description}
                </p>
              </div>
              <div className="mt-6 flex items-center text-xs font-semibold text-indigo-600 group-hover:underline">
                Run Validation Scanner <ArrowRight className="h-4 w-4 ml-1.5 transition-transform group-hover:translate-x-1" />
              </div>
            </div>
          );
        })}
      </div>

      {/* Statistics Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-800 flex items-center space-x-2">
              <TrendingUp className="h-4 w-4 text-indigo-500" />
              <span>Authenticity Evaluation Timeline</span>
            </h3>
            <span className="text-xs text-slate-400 font-medium">Recent Analysis Runs</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData.length > 0 ? chartData : fallbackData}>
                <defs>
                  <linearGradient id="colorAuth" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} domain={[0, 100]} />
                <Tooltip />
                <Area type="monotone" dataKey="authenticity" stroke="#4f46e5" fillOpacity={1} fill="url(#colorAuth)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-800 flex items-center space-x-2 mb-4">
              <Activity className="h-4 w-4 text-emerald-500" />
              <span>Status Aggregate</span>
            </h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-xl bg-emerald-50 border border-emerald-100">
                <div className="flex items-center space-x-2.5">
                  <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                  <span className="text-xs font-semibold text-emerald-800">Clear & Certified</span>
                </div>
                <span className="text-sm font-bold text-emerald-700">{scans.length ? safeCount : 0}</span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-amber-50 border border-amber-100">
                <div className="flex items-center space-x-2.5">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <span className="text-xs font-semibold text-amber-800">Suspicious Elements</span>
                </div>
                <span className="text-sm font-bold text-amber-700">{scans.length ? suspiciousCount : 0}</span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-red-50 border border-red-100">
                <div className="flex items-center space-x-2.5">
                  <AlertOctagon className="h-5 w-5 text-red-600" />
                  <span className="text-xs font-semibold text-red-800">Dangerous Indicators</span>
                </div>
                <span className="text-sm font-bold text-red-700">{scans.length ? dangerCount : 0}</span>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-100 pt-4 mt-6">
            <p className="text-[11px] text-slate-400 text-center font-medium">
              Data protected under algorithmic cryptographic checks.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
