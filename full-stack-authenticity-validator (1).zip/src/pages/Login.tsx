import React, { useState } from 'react';
import { KeyRound, Mail, AlertCircle, CheckCircle2 } from 'lucide-react';
import { mockDB } from '../utils/mockDatabase';

interface LoginProps {
  onLoginSuccess: (user: any) => void;
  onNavigate: (view: string) => void;
}

export default function Login({ onLoginSuccess, onNavigate }: LoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!email || !password) {
      setError('Please fill in all credentials.');
      return;
    }

    const res = mockDB.loginUser(email, password);
    if (!res.success) {
      setError(res.message);
    } else {
      setSuccess('Logged in securely!');
      setTimeout(() => {
        onLoginSuccess(res.user);
        onNavigate('dashboard');
      }, 800);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-[calc(100vh-10rem)] p-4 animate-fadeIn">
      <div className="w-full max-w-md bg-white border border-slate-200 rounded-2xl p-8 shadow-xl shadow-slate-100">
        <div className="text-center mb-6">
          <div className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600 mb-4">
            <KeyRound className="h-6 w-6 font-bold" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 tracking-tight">Access Verification</h2>
          <p className="text-slate-500 text-xs mt-1 leading-relaxed">
            Manage authentication workflows and query scanned payloads safely.
          </p>
        </div>

        {error && (
          <div className="mb-4 flex items-center space-x-2 p-3 text-xs font-semibold text-red-600 bg-red-50 border border-red-200 rounded-xl">
            <AlertCircle className="h-4 w-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="mb-4 flex items-center space-x-2 p-3 text-xs font-semibold text-emerald-600 bg-emerald-50 border border-emerald-200 rounded-xl">
            <CheckCircle2 className="h-4 w-4 shrink-0" />
            <span>{success}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
              Email Address
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                <Mail className="h-4 w-4" />
              </span>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@domain.com"
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
              Secure Password
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                <KeyRound className="h-4 w-4" />
              </span>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3 mt-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-bold shadow-md shadow-indigo-100 transition duration-150 ease-in-out"
          >
            Authenticate User
          </button>
        </form>

        <div className="mt-6 text-center text-xs text-slate-500 font-medium">
          No records yet?{' '}
          <button
            onClick={() => onNavigate('register')}
            className="text-indigo-600 hover:underline font-bold ml-1"
          >
            Create localized sandbox account
          </button>
        </div>
      </div>
    </div>
  );
}
