import React, { useState } from 'react';
import { 
  Video, CheckCircle2, AlertCircle, AlertOctagon,
  Loader2, Radio, Play, Sparkles, RefreshCw
} from 'lucide-react';
import { mockDB, ScanResult } from '../utils/mockDatabase';

interface MediaDetectorProps {
  user: any;
}

export default function MediaDetector({ user }: MediaDetectorProps) {
  const [file, setFile] = useState<File | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<ScanResult | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setResult(null);
    }
  };

  const handleAnalyze = () => {
    if (!file) return;
    setAnalyzing(true);
    
    setTimeout(() => {
      const type = file.type.startsWith('video/') ? 'video' : 'audio';
      const scanResult = mockDB.analyzeMedia(file, type, user?.id);
      setResult(scanResult);
      setAnalyzing(false);
    }, 3000);
  };

  const resetScanner = () => {
    setFile(null);
    setResult(null);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-800 tracking-tight flex items-center space-x-2">
          <Video className="h-6 w-6 text-indigo-600 font-semibold" />
          <span>Deepfake & Synthesized Media Detection</span>
        </h1>
        <p className="text-slate-500 text-xs mt-1">
          Scrutinize audio spectrums and video multi-frame anomalies against known artificial voice configurations.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <div className="lg:col-span-3 space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
            <div className="border-2 border-dashed border-slate-200 hover:border-indigo-400 hover:bg-slate-50/50 rounded-xl p-8 text-center cursor-pointer transition-all relative">
              <input 
                type="file" 
                accept="audio/*,video/*"
                onChange={handleFileChange}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
              
              <div className="space-y-3">
                <div className="h-12 w-12 bg-indigo-50 text-indigo-600 rounded-xl mx-auto flex items-center justify-center">
                  <Radio className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-700">
                    {file ? file.name : "Insert multimedia streams here"}
                  </p>
                  <p className="text-xs text-slate-400 mt-1">
                    Accepts MP3, MP4, WAV, MOV (Max 50MB)
                  </p>
                </div>
              </div>
            </div>

            {file && !analyzing && !result && (
              <div className="mt-4 flex items-center justify-between">
                <div className="flex items-center text-xs text-slate-500 space-x-1 font-medium bg-slate-100 px-3 py-1.5 rounded-lg">
                  <Play className="h-3.5 w-3.5 text-slate-400 fill-slate-400" />
                  <span>Media Loaded</span>
                </div>
                <button
                  onClick={handleAnalyze}
                  className="flex items-center space-x-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-bold transition shadow"
                >
                  <Sparkles className="h-4 w-4" />
                  <span>Examine Timelines</span>
                </button>
              </div>
            )}

            {analyzing && (
              <div className="mt-6 flex flex-col items-center justify-center text-center space-y-3 py-6">
                <Loader2 className="h-8 w-8 text-indigo-600 animate-spin" />
                <p className="text-sm font-semibold text-slate-700">Profiling waveform distributions...</p>
                <p className="text-xs text-slate-400">Comparing lip-sync micro-shading discrepancies</p>
              </div>
            )}
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wide mb-2">Neural checks performed:</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-500">
              <div className="p-3 bg-white border border-slate-200 rounded-xl flex items-center space-x-2">
                <CheckCircle2 className="h-4 w-4 text-indigo-500 shrink-0" />
                <span>Facial Frame Mesh tracking</span>
              </div>
              <div className="p-3 bg-white border border-slate-200 rounded-xl flex items-center space-x-2">
                <CheckCircle2 className="h-4 w-4 text-indigo-500 shrink-0" />
                <span>Audio clipping manipulation</span>
              </div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-2">
          {result ? (
            <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-5 animate-fadeIn">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-800">Spectrogram Overview</h3>
                <button 
                  onClick={resetScanner} 
                  className="text-xs font-semibold text-slate-400 hover:text-slate-600 flex items-center space-x-1"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  <span>Clear</span>
                </button>
              </div>

              <div className="flex flex-col items-center py-4 border-b border-slate-100">
                <div className={`h-24 w-24 rounded-full flex flex-col items-center justify-center border-4 border-slate-100 relative ${
                  result.status === 'safe' 
                    ? 'text-emerald-600 border-t-emerald-500 border-r-emerald-500' 
                    : result.status === 'suspicious' 
                    ? 'text-amber-500 border-t-amber-400 border-r-amber-400' 
                    : 'text-red-600 border-t-red-500 border-r-red-500'
                }`}>
                  <span className="text-2xl font-bold">{result.authenticityScore}%</span>
                  <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">Safe Prob</span>
                </div>
                <span className={`text-xs font-bold mt-3 px-3 py-1 rounded-full border ${
                  result.status === 'safe' 
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-100' 
                    : result.status === 'suspicious' 
                    ? 'bg-amber-50 text-amber-700 border-amber-100' 
                    : 'bg-red-50 text-red-700 border-red-100'
                }`}>
                  {result.status.toUpperCase()}
                </span>
              </div>

              <div className="space-y-3">
                <div className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center space-x-1">
                  <AlertCircle className="h-4 w-4 text-indigo-500" />
                  <span>Observation Notes</span>
                </div>
                {result.details.threatsDetected.map((thr, index) => (
                  <div key={index} className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-start space-x-2.5">
                    {result.status === 'safe' ? (
                      <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                    ) : result.status === 'suspicious' ? (
                      <AlertCircle className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
                    ) : (
                      <AlertOctagon className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
                    )}
                    <p className="text-xs text-slate-600 leading-normal">{thr}</p>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="bg-slate-50 border border-slate-200 border-dashed rounded-2xl p-10 text-center flex flex-col items-center justify-center text-slate-400 h-full min-h-[300px]">
              <Video className="h-10 w-10 text-slate-300 mb-3" />
              <p className="text-xs font-semibold">Waveform output expects file submission inputs.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
