import { 
  History, ShieldAlert, CheckCircle2, AlertOctagon, AlertCircle, FileSearch, Video, FileText
} from 'lucide-react';
import { mockDB, ScanResult } from '../utils/mockDatabase';

interface HistoryViewerProps {
  user: any;
  onNavigate: (view: string) => void;
}

export default function HistoryViewer({ user, onNavigate }: HistoryViewerProps) {
  const scans = mockDB.getScans(user?.id);

  const getIcon = (category: string) => {
    switch (category) {
      case 'forgery': return <FileSearch className="h-5 w-5 text-indigo-500" />;
      case 'media': return <Video className="h-5 w-5 text-violet-500" />;
      case 'scam_text': return <FileText className="h-5 w-5 text-blue-500" />;
      default: return <History className="h-5 w-5 text-slate-400" />;
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-800 tracking-tight flex items-center space-x-2">
          <History className="h-6 w-6 text-indigo-600 font-semibold" />
          <span>Verification Database Logs</span>
        </h1>
        <p className="text-slate-500 text-xs mt-1">
          Internal reporting index monitoring algorithmic security checkpoints.
        </p>
      </div>

      {!user && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <AlertCircle className="h-5 w-5 text-amber-600 shrink-0" />
            <p className="text-xs text-amber-800 font-medium leading-relaxed">
              <strong>Notice:</strong> Currently using temporary guest state. To store historical data across separate devices, configure a verified identity.
            </p>
          </div>
          <button 
            onClick={() => onNavigate('login')}
            className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold transition whitespace-nowrap"
          >
            Authenticate
          </button>
        </div>
      )}

      {scans.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center flex flex-col items-center justify-center space-y-3">
          <ShieldAlert className="h-10 w-10 text-slate-300" />
          <h3 className="text-sm font-bold text-slate-700">Database queries returned null</h3>
          <p className="text-xs text-slate-400 max-w-sm">
            Execute analytical functions via category links first to generate index targets.
          </p>
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-600 uppercase tracking-wider">
                  <th className="px-6 py-4">Item Target</th>
                  <th className="px-6 py-4">Type</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4">Credibility</th>
                  <th className="px-6 py-4">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-600 font-medium">
                {scans.map((item: ScanResult) => (
                  <tr key={item.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4 flex items-center space-x-3">
                      <div className="p-2 bg-slate-50 rounded-lg border border-slate-100 shrink-0">
                        {getIcon(item.category)}
                      </div>
                      <span className="text-xs font-bold text-slate-800 truncate max-w-[200px]">
                        {item.fileName}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-xs font-semibold uppercase text-slate-400 tracking-wide">
                      {item.fileType}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold border capitalize ${
                        item.status === 'safe'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-100'
                          : item.status === 'suspicious'
                          ? 'bg-amber-50 text-amber-700 border-amber-100'
                          : 'bg-red-50 text-red-700 border-red-100'
                      }`}>
                        {item.status === 'safe' ? (
                          <CheckCircle2 className="h-3.5 w-3.5" />
                        ) : item.status === 'suspicious' ? (
                          <AlertCircle className="h-3.5 w-3.5" />
                        ) : (
                          <AlertOctagon className="h-3.5 w-3.5" />
                        )}
                        <span>{item.status}</span>
                      </span>
                    </td>
                    <td className="px-6 py-4 text-xs font-bold text-slate-700">
                      {item.authenticityScore}%
                    </td>
                    <td className="px-6 py-4 text-xs text-slate-400 font-normal">
                      {new Date(item.scannedAt).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
