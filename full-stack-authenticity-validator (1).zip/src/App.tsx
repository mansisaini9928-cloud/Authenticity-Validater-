import { useState, useEffect } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import LandingDashboard from './pages/LandingDashboard';
import Login from './pages/Login';
import Register from './pages/Register';
import ForgeryDetector from './pages/ForgeryDetector';
import MediaDetector from './pages/MediaDetector';
import TextDetector from './pages/TextDetector';
import HistoryViewer from './pages/HistoryViewer';
import { User } from './utils/mockDatabase';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<string>('dashboard');

  useEffect(() => {
    // Check if user session already bound
    const savedUser = localStorage.getItem('current_auth_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const handleLogin = (authenticatedUser: User) => {
    setUser(authenticatedUser);
    localStorage.setItem('current_auth_user', JSON.stringify(authenticatedUser));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('current_auth_user');
    setCurrentView('dashboard');
  };

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <LandingDashboard onNavigate={setCurrentView} user={user} />;
      case 'login':
        return <Login onLoginSuccess={handleLogin} onNavigate={setCurrentView} />;
      case 'register':
        return <Register onNavigate={setCurrentView} />;
      case 'forgery':
        return <ForgeryDetector user={user} />;
      case 'media':
        return <MediaDetector user={user} />;
      case 'text':
        return <TextDetector user={user} />;
      case 'history':
        return <HistoryViewer user={user} onNavigate={setCurrentView} />;
      default:
        return <LandingDashboard onNavigate={setCurrentView} user={user} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans antialiased">
      <Header 
        user={user} 
        onLogout={handleLogout} 
        onNavigate={setCurrentView} 
        currentView={currentView} 
      />
      
      <div className="flex flex-1">
        <Sidebar 
          currentView={currentView} 
          onNavigate={setCurrentView} 
        />
        
        <main className="flex-1 p-6 md:p-8 max-w-7xl mx-auto w-full">
          {renderView()}
        </main>
      </div>

      <footer className="border-t border-slate-200 bg-white/50 text-center py-4 text-xs text-slate-400 font-medium">
        AuthVerify Digital Risk Shielding © {new Date().getFullYear()}. Secure Execution Contexts.
      </footer>
    </div>
  );
}
